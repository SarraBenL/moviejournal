function openPage(pageURL)
{
  window.location.href = pageURL;
}
